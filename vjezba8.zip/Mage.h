#pragma once
#ifndef MAGE_H
#define MAGE_H

#include "Player.h"

class Mage : public Player {
    unsigned mana;

public:
    Mage(const string& name);

    virtual ~Mage() {}

    void specialAbility() override;

    void attackEnemy(Enemy* target) override;

    void displayStatus() const override;
};

#endif
