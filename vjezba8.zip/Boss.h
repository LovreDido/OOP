#pragma once
#ifndef BOSS_H
#define BOSS_H

#include "Enemy.h"

class Boss : public Enemy {
public:
    Boss(const string& name);
    virtual ~Boss() {}

    void specialAbility() override;
    void attackPlayer(Player* target) override;
    void displayStatus() const override;
};

#endif
