#include "Warrior.h"
#include "Enemy.h"

Warrior::Warrior(const string& name)
	: Player(120, name), shield(false){}

void Warrior::specialAbility() {
	cout << name << " uzima stit!" << endl;
	shield = true;
}

void Warrior::takeDamage(unsigned dmg) {
	if (!shield) {
		dmg /= 2;
		shield = false;
	}
	GameCharacter::takeDamage(dmg);
}

void Warrior::attackEnemy(Enemy* target) {
	if (!isAlive()) return;

	cout << name << " napada macem!" << endl;

	if (target->isAlive()) {
		target->takeDamage(20);
		if (!target->isAlive()) addScore(10);
	}
}

void Warrior::displayStatus() const {
	cout << "[Warrior] " << name << " HP: " << health << endl;
}