#include "Gnome.h"
#include "Player.h"

Gnome::Gnome(const string& name)
    : Enemy(90, name, 3) {
}

void Gnome::specialAbility() {
    if (health > 20)
        cout << name << " svira trubu! Dolazite gnomovi!" << endl;
}

void Gnome::attackPlayer(Player* target) {
    if (!isAlive()) return;
    cout << name << " napada lukom!" << endl;
    target->takeDamage(5 * difficulty);
}

void Gnome::displayStatus() const {
    cout << "[Gnome] " << name
        << " HP: " << health
        << " Difficulty: " << difficulty
        << endl;
}
