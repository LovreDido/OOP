#include "Mage.h"
#include "Enemy.h"

Mage::Mage(const string& name)
    : Player(80, name), mana(100) {
}

void Mage::specialAbility() {
    if (health > 50)
        cout << name << " se teleportira!" << endl;
    else
        cout << name << " je preslab za teleport!" << endl;
}

void Mage::attackEnemy(Enemy* target) {
    if (!isAlive()) return;

    if (mana >= 20) {
        cout << name << " baca vatrenu kuglu!" << endl;
        target->takeDamage(40);
        mana -= 20;
    }
    else {
        cout << name << " udara stapom!" << endl;
        target->takeDamage(20);
    }

    if (!target->isAlive()) addScore(10);
}

void Mage::displayStatus() const {
    cout << "[Mage] " << name << " HP: " << health
        << " Mana: " << mana << endl;
}
