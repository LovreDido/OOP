#include "GameCharacter.h"

GameCharacter::GameCharacter(unsigned health, const string& name)
	: health(health), name(name) {}

GameCharacter::~GameCharacter() {}

unsigned GameCharacter::getHealth() const { return health; }

string GameCharacter::getName() const { return name; }

/*
virtual void displayStatus() const = 0 {
	cout << "Status:\nName: " << name << "\tHealth: " << health << endl;
}

virtual void specialAbility() = 0 {
	cout << "!!! S p e c i a l	A b i l i t y !!!" << endl;
}
*/

void GameCharacter::takeDamage(unsigned dmg) {
	if (dmg >= health) health = 0;
	else health -= dmg;
}

bool GameCharacter::isAlive() const { return health > 0; }

