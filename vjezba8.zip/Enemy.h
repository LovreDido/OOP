#pragma once
#ifndef ENEMY_H
#define ENEMY_H

#include "GameCharacter.h"

class Player;

class Enemy : public GameCharacter {
protected:
	unsigned difficulty;

public:
	Enemy(unsigned health, const string& name, unsigned difficulty);

	virtual ~Enemy() {}

	unsigned getDifficulty() const;

	virtual void attackPlayer(Player* target) = 0;
};

#endif