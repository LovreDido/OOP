#include <iostream>
#include <vector>
using namespace std;

#include "Warrior.h"
#include "Mage.h"
#include "Gnome.h"
#include "Boss.h"

int main() {
    vector<GameCharacter*> chars;

    Warrior* conan = new Warrior("Conan");
    Mage* merlin = new Mage("Merlin");
    Gnome* gnomeo = new Gnome("Gnomeo");
    Gnome* sneaky = new Gnome("Sneaky");
    Boss* dragon = new Boss("Dragon");

    chars.push_back(conan);
    chars.push_back(merlin);
    chars.push_back(gnomeo);
    chars.push_back(sneaky);
    chars.push_back(dragon);

    // Fight simulation
    conan->attackEnemy(gnomeo);
    merlin->attackEnemy(sneaky);
    gnomeo->attackPlayer(conan);
    merlin->attackEnemy(gnomeo);
    dragon->attackPlayer(merlin);
    merlin->attackEnemy(gnomeo);
    conan->attackEnemy(dragon);
    merlin->attackEnemy(dragon);

    cout << "\n=== SPECIAL ABILITIES ===\n";
    for (auto c : chars) c->specialAbility();

    cout << "\n=== SURVIVORS ===\n";
    GameCharacter* best = nullptr;

    for (auto c : chars) {
        if (c->isAlive()) {
            c->displayStatus();
            if (!best || c->getHealth() > best->getHealth())
                best = c;
        }
    }

    cout << "\nCharacter s najvise zdravlja: "
        << best->getName() << endl;

    for (auto c : chars) delete c;

    return 0;
}
