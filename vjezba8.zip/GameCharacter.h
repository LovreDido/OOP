#pragma once
#ifndef GAMECHARACTER_H
#define GAMECHARACTER_H

#include <string>
#include <iostream>
using namespace std;

class Player;
class Enemy;

class GameCharacter {
protected:
	unsigned health;
	string name;
public:
	GameCharacter(unsigned health, const string& name);

	virtual ~GameCharacter();

	unsigned getHealth() const;

	string getName() const;

	virtual void displayStatus() const = 0;
	
	virtual void specialAbility() = 0;
	
	void takeDamage(unsigned dmg);
	
	bool isAlive() const;
};

#endif