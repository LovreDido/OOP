#include "Boss.h"
#include "Player.h"

Boss::Boss(const string& name)
    : Enemy(300, name, 8) {
}

void Boss::specialAbility() {
    cout << name << " se regenerira!" << endl;
    health += 50;
    if (health > 300) health = 300;
}

void Boss::attackPlayer(Player* target) {
    if (!isAlive()) return;
    cout << name << " razbija zemlju!" << endl;
    target->takeDamage(10 * difficulty);
}

void Boss::displayStatus() const {
    cout << "[Boss] " << name
        << " HP: " << health
        << " Difficulty: " << difficulty
        << endl;
}
