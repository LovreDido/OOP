#pragma once
#ifndef WARRIOR_H
#define WARRIOR_H

#include "Player.h"

class Warrior : public Player {
	bool shield;

public:
	Warrior(const string& name);

	virtual ~Warrior() {}

	void specialAbility() override;

	void takeDamage(unsigned dmg);

	void attackEnemy(Enemy* target) override;

	void displayStatus() const override;

};

#endif