#include "Player.h"

Player::Player(unsigned health, const string& name)
	: GameCharacter(health, name), score(0) {}

/*
Player::~Player() {
	cout << "Player: destruktor pozvan" << endl;
}

virtual void attackEnemy(Enemy* target) {
	if (health > 0) {
		(*target).takeDamage();

		if (target->getHealth() = 0)
			addScore(10);
	}
}
*/

void Player::addScore(int s) {
	score += s;
}

