#include "Enemy.h"

Enemy::Enemy(unsigned health, const string& name, unsigned difficulty)
	: GameCharacter(health, name), difficulty(difficulty) {}

unsigned Enemy::getDifficulty() const { return difficulty; }


/*
virtual void attackPlayer(Player* target) {
	if (health > 0) {
		(*target).takeDamage();

		if (target->getHealth() = 0)
			return;
	}
}

~Enemy() {
	cout << "Enemy: destruktor pozvan" << endl;
}
*/