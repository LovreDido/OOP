#pragma once
#ifndef GNOME_H
#define GNOME_H

#include "Enemy.h"

class Gnome : public Enemy {
public:
    Gnome(const string& name);
    virtual ~Gnome() {}

    void specialAbility() override;
    void attackPlayer(Player* target) override;
    void displayStatus() const override;
};

#endif
